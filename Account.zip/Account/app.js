import express from 'express';
import cors from 'cors';
import * as db from './util/database.js';

const app = express();
const PORT = 5050;

app.use(cors());
app.use(express.json());

app.get('/partners', (_, res) => res.json(db.getPartners()));
app.get('/customers', (_, res) => res.json(db.getCustomers()));
app.get('/invoices', (_, res) => res.json(db.getInvoices()));

app.post('/invoices', (req, res) => {
  const { issuerId, customerId, issueDate, completionDate, paymentDeadline, total, item } = req.body;

  if (!issuerId || !customerId || !issueDate || !item || total == null) {
    return res.status(400).json({ message: 'Hiányzó mezők' });
  }

  const vat = Math.round(total * 0.27);

  const result = db.saveInvoice({ issuerId, customerId, issueDate, completionDate, paymentDeadline, total, vat, item });

  if (result.changes !== 1) return res.status(500).json({ message: 'Mentés sikertelen' });

  res.status(201).json({ message: 'Számla elmentve' });
});


app.put('/invoices/:id', (req, res) => {
  const id = +req.params.id;
  const { issuerId, customerId, issueDate, completionDate, paymentDeadline, total, item } = req.body;

  const vat = Math.round(total * 0.27);

  const result = db.updateInvoice(id, { issuerId, customerId, issueDate, completionDate, paymentDeadline, total, vat, item });

  if (result.changes !== 1) return res.status(404).json({ message: 'Nem található vagy nem sikerült módosítani' });
  res.status(200).json({ message: 'Frissítve' });
});


app.put('/invoices/:id/pay', (req, res) => {
  const id = +req.params.id;
  const result = db.markInvoicePaid(id);
  if (result.changes !== 1) return res.status(404).json({ message: 'Nem található vagy már ki van fizetve' });
  res.json({ message: 'Kifizetve' });
});

app.delete('/invoices/:id', (req, res) => {
  const id = +req.params.id;
  const result = db.deleteInvoice(id);
  if (result.changes !== 1) return res.status(404).json({ message: 'Nem sikerült törölni' });
  res.status(200).json({ message: 'Törölve' });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
