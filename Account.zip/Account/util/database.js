import Database from 'better-sqlite3';

const db = new Database('./data/database.sqlite');

db.prepare(`
CREATE TABLE IF NOT EXISTS invoices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT,
  issuerId INTEGER,
  customerId INTEGER,
  issueDate TEXT,
  completionDate TEXT,
  paymentDeadline TEXT,
  total INTEGER,
  vat INTEGER,
  item TEXT,
  paid INTEGER DEFAULT 0
)
`).run();

db.prepare(`
CREATE TABLE IF NOT EXISTS partners (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL
)
`).run();

db.prepare(`
CREATE TABLE IF NOT EXISTS customers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL
)
`).run();

const partners = [
  { name: "Kék Kft." },
  { name: "Zöld Bt." },
  { name: "Piros Rt." }
];

const customers = [
  { name: "Nagy Péter", address: "1111 Budapest, Példa u. 1.", taxNumber: "12345678-1-42" },
  { name: "Kis Anna", address: "2222 Budapest, Minta krt. 2.", taxNumber: "87654321-1-33" },
  { name: "Kovács Kft.", address: "3333 Szeged, Teszt tér 3.", taxNumber: "11223344-2-12" }
];

const partnerInsert = db.prepare("INSERT INTO partners (name) VALUES (?)");
const customerInsert = db.prepare("INSERT INTO customers (name) VALUES (?)");
const invoiceInsert = db.prepare(`
  INSERT INTO invoices 
    (code, issuerId, customerId, issueDate, completionDate, paymentDeadline, total, vat, item) 
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
`);

if (db.prepare("SELECT COUNT(*) AS count FROM partners").get().count === 0) {
  for (const p of partners) partnerInsert.run(p.name);
}

if (db.prepare("SELECT COUNT(*) AS count FROM customers").get().count === 0) {
  for (const c of customers) customerInsert.run(c.name);
}

const allPartners = db.prepare("SELECT * FROM partners").all();
const allCustomers = db.prepare("SELECT * FROM customers").all();

const today = new Date().toISOString().split("T")[0];
const dueDate = new Date();
dueDate.setDate(new Date().getDate() + 30);
const due = dueDate.toISOString().split("T")[0];

const invoiceExists = db.prepare("SELECT COUNT(*) AS count FROM invoices").get().count > 0;

if (!invoiceExists) {
  let invoiceCount = 1;
  for (const customer of allCustomers) {
    for (let i = 1; i <= 3; i++) {
      const issuer = allPartners[i % allPartners.length];
      const total = 10000 + Math.floor(Math.random() * 9000);
      const vat = Math.round(total * 0.27);
      const code = `SZOT-${today.slice(0, 7)}-${String(invoiceCount++).padStart(3, '0')}`;
      invoiceInsert.run(code, issuer.id, customer.id, today, today, due, total, vat, `Szolgáltatás #${i}`);
    }
  }
}

export const getPartners = () => db.prepare('SELECT * FROM partners').all();
export const getCustomers = () => db.prepare('SELECT * FROM customers').all();
export const getInvoices = () => db.prepare('SELECT * FROM invoices WHERE paid = 0').all();

export const countInvoicesByMonth = (month, year) =>
  db.prepare('SELECT COUNT(*) as count FROM invoices WHERE issueDate LIKE ?').get(`${year}-${month.padStart(2, '0')}%`).count;

export const generateCode = (issueDate) => {
  const [year, month] = issueDate.split('-');
  const count = countInvoicesByMonth(month, year) + 1;
  return `SZOT-${year}-${month}-${String(count).padStart(3, '0')}`;
};

export const saveInvoice = (inv) => {
  const code = generateCode(inv.issueDate);
  return db.prepare(`
    INSERT INTO invoices (code, issuerId, customerId, issueDate, completionDate, paymentDeadline, total, vat, item)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(code, inv.issuerId, inv.customerId, inv.issueDate, inv.completionDate, inv.paymentDeadline, inv.total, inv.vat, inv.item);
};


export const updateInvoice = (id, inv) =>
  db.prepare(`
    UPDATE invoices SET
      issuerId = ?, customerId = ?, issueDate = ?, completionDate = ?, paymentDeadline = ?, total = ?, vat = ?, item = ?
    WHERE id = ?
  `).run(inv.issuerId, inv.customerId, inv.issueDate, inv.completionDate, inv.paymentDeadline, inv.total, inv.vat, inv.item, id);

export const markInvoicePaid = (id) =>
  db.prepare('UPDATE invoices SET paid = 1 WHERE id = ?').run(id);

export const deleteInvoice = (id) =>
  db.prepare('DELETE FROM invoices WHERE id = ?').run(id);


// db.prepare(`INSERT INTO partners (name) VALUES ('Teszt Partner')`).run();
// db.prepare(`INSERT INTO customers (name) VALUES ('Teszt Vevő')`).run();
